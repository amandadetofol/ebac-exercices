//
//  ViewController.swift
//  Projeto Final
//
//  Created by c94292a on 17/11/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .blue //mudando a cor de fundo da view para azul
    }


}

