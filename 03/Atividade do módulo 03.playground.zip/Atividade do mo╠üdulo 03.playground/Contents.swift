//Parte 01
var num1 : Int = 10 //crio uma variavel do tipo Int que recebe o valor 10 na sua inicializacao
var num2 : Int = 20 // crio uma variavel do tipo int que recebe o valor 20 na sua inicializacao

var soma : Int = num1 + num2 //crio uma variavel do tipo inteiro que ira armazenar a soma de num1 + num2

print(soma) //mostro o resultado da soma no console



//Parte 02
//O tipo let não pode ser alterado ao longo da execução do código pois ele é declarado como uma constante. Exemplo:
let valorMinimo : Int = 7
//o valorMinimo sempre terá o valor de 7



//Parte 03
//O melhor tipo de váriavel / constante para armazenar texto  é o tipo String. Exemplos:

var nome : String = "Amanda" //armazeno o text Amanda dentro de uma váriavel string que pode ser modificado ao longo da execucao do programa

let cidade : String = "Blumenau" // armazeno o texto Blumenau dentro de uma constante do tipo String que nao pode ser alterado ao longo da execucao do programa

